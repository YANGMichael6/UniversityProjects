#Activité 9: Fréquence dans des textes

#1 Partie Guidée: Occurence des mots

def ouvre_fichier(nom : str) -> List[str] :
    """ renvoie la liste des lignes du fichier texte ./ nom.txt """
    with open("./" + nom + ".txt", "r", encoding = "utf −8") as f:
        return f. readlines ()

#Q1)

def decompose_ligne(li: str, sep: Set[str]) -> List[str]:
    """Renvoie une liste de chaînes de caractères, correspondant au découpage de li selon le caractère sep."""
    res: List[str] = []
    i: str
    mot: str = ''
    for i in li:
        if i not in sep:
            mot = mot + i
        elif mot != '':
            res.append(mot)
            mot = ''
    if mot not in sep and mot != '':
        res.append(mot)
    return res

exemple1: List[str] = ouvre_fichier("beaute") 
ponctuation : Set[str] = {" ", ",", ";", "’", "(", ")", ".", "!", "?", ":", "\n"}

assert decompose_ligne(exemple1[0], ponctuation) == ['Je', 'suis', 'belle', 'ô', 'mortels', 'comme', 'un', 'rêve', 'de', 'pierre']
assert decompose_ligne(exemple1[4], ponctuation) == [] 
assert decompose_ligne(exemple1[8], ponctuation) == ['Et', 'jamais', 'je', 'ne', 'pleure', 'et', 'jamais', 'je', 'ne', 'ris']

#Q2)

def minusculise(c: str) -> str:
    """Renvoie la chaîne de caractères c en minuscule"""
    res: str = ''
    i: str
    for i in c:
        if 90 >= ord(i) >= 65:
            res = res + chr(ord(i)+32)
        else:
            res = res + i
    return res

assert minusculise("bonjour") == "bonjour"
assert minusculise("BONJOUR") == "bonjour"
assert minusculise ("Bonjour") == "bonjour" 
    
#Q3)

def mots(lis: List[str], sep: Set[str]) -> List[str]:
    """Renvoie la liste c en minuscule et sans les caractères dans sep"""
    return [minusculise(k) for i in lis for k in decompose_ligne(i, sep)]

assert mots(exemple1, ponctuation )[:15]== ['je', 'suis', 'belle', 'ô', 'mortels', 'comme', 'un','rêve', 'de', 'pierre', 'et', 'mon', 'sein', 'où', 'chacun']

#Q4)

def dictionnaire_occ_mots(ms: List[str]) -> Dict[str,int]:
    """Construit le dictionnaire des occurences des mots de ms."""
    res: Dict[str, int] = dict()
    i: str
    for i in ms:
        if i in res:
            res[i] = res[i] + 1
        else:
            res[i] = 1
    return res

dico1: Dict[str , int] = dictionnaire_occ_mots(mots(exemple1, ponctuation))

assert dico1["je"] == 5
assert dico1["belle"] == 1
assert dico1["jamais"] == 2

#Q5)

def hapax(occ: Dict[str,int]) -> Set[str]:
    """renvoie l’ensemble des hapax de occ."""
    return {c for c, v in occ.items() if v == 1}

def hapax2(occ: Dict[str,int]) -> Set[str]:
    """renvoie l’ensemble des hapax de occ."""
    return {i for i in occ if occ[i] == 1}

assert len(hapax2(dico1)) == 68 # Cela est dû au fait que notre texte possède des caractères avec accent tel que "ô", "où"...
assert ("sphinx" in hapax2(dico1)) == True
assert ("jamais" in hapax2(dico1)) == False

#Q6)

def plus_frequent(occ: Dict[str, int]) -> str:
    """Renvoie le premier mot dans l’ordre du dictionnaire avec le nombre d’occurences le plus élevée."""
    res: str = ''
    m: int = 0
    for c, v in occ.items():
        if v > m:
            res = c
            m = v
    return res

assert plus_frequent(dico1) == "je"

#2 SUGGESTION: Comparaisonn de fréquences

#Q1)

def dictionnaire_freq_mots(ms: List[str]) -> Dict[str, float]:
    """Construit le dictionnaire des fr´equence des mots de ms."""
    l: int = len(ms)
    res: Dict[str, float] = dict()
    d: Dict[str,int] = dictionnaire_occ_mots(ms)
    for c, v in d.items():
        res[c] = v/l
    return res

dico2 : Dict[str , float] = dictionnaire_freq_mots(mots(exemple1 , ponctuation))
assert dico2["je"] == 0.043478260869565216
assert dico2["belle"] == 0.008695652173913044
#Il doit y avoir un une différence dûe à la fonction minusculise.

#Q2)

def distance_freq(d1: Dict[str, float], d2: Dict[str, float]) -> float:
    """Renvoie la distance de d2 à d1 selon un modèle."""
    score: float = 100.0
    vus: Set[str] = set()
    v1: float
    v2: float
    mot1: str
    for mot1 in d1:
        v1 = d1[mot1]
        if mot1 in d2:
            v2 = d2[mot1]
        else:
            v2 = 0.0
        score = score - 100.0 * abs(v1 - v2)
        vus.add(mot1)
    mot2: str
    for mot2 in d2:
        if mot2 not in vus:
            v2 = d2[mot2]
            score = score - 100.0 * abs(0.0 - v2)
    return score

assert distance_freq(dico2, dico2) == 100

#3 SUGGESTION: Auteur d'un texte

#Q1)

def jointure_dict_freq(d1: Dict[str, float], d2: Dict[str, float]) -> Dict[str, float]:
    """Renvoie un dictionnaire de frequence d qui joint d1 et d2 en un unique dictionnaire"""
    l1: int = len(d1.items())
    l2: int = len(d2.items())
    res: Dict[str, float] = dict()
    for c1, v1 in d1.items():
        if c1 in d2:
            res[c1] = (v1 * l1 + d2[c1] * l2) / (l1 + l2)
        else:
            res[c1] = (v1 * l1) / (l1 + l2)
    for c2, v2 in d2.items():
        if c2 in d1:
            res[c2] = (v2 * l2 + d1[c2] * l1) / (l1 + l2)
        else:
            res[c2] = (v2 * l2) / (l1 + l2)
    return res

#Q2)

def dict_auteur(li: List[str]) -> Dict[str, float]:
    """Construit le dictionnaire de fréquence des mots apparaissant dans les fichiers dont le nom apparait dans li."""
    ponctuation: Set[str] = {" ", ",", ";", "’", "(", ")", ".", "!", "?", ":", "\n"}
    fichiers: List[Dict[str, float]] = []
    nom: str
    for nom in li:
        mots_fichier: List[str] = mots(ouvre_fichier(nom), ponctuation)
        fichiers.append(dictionnaire_freq_mots(mots_fichier))
    res: Dict[str, float] = fichiers[0]
    k: int
    for k in range(1, len(fichiers)):
        res = jointure_dict_freq(res, fichiers[k])
    return res

baudelaire : Dict[str, float] = dict_auteur(["beaute", "spleen", "albatros"])

#Q3)

def auteur(candidats: List[Tuple[str, Dict[str, float]]], titre: str) -> str:
    """Renvoie le nom de l’auteur de candidats le plus probable pour le fichier nom dans candidats."""
    ponctuation: Set[str] = {" ", ",", ";", "’", "(", ")", ".", "!", "?", ":", "\n"}
    ms: List[str] = mots(ouvre_fichier(titre), ponctuation)
    d_inconnu: Dict[str, float] = dictionnaire_freq_mots(ms)
    meilleur_nom, d = candidats[0]
    meilleur_score: float = distance_freq(d, d_inconnu)
    for nom, d_freq in candidats[1:]:
        score:float = distance_freq(d_freq, d_inconnu)
        if score > meilleur_score:
            meilleur_score = score
            meilleur_nom = nom
    return meilleur_nom

d_beaute: Dict[str, float] = dictionnaire_freq_mots(mots(ouvre_fichier("beaute"),   ponctuation))
d_albatros: Dict[str, float] = dictionnaire_freq_mots(mots(ouvre_fichier("albatros"), ponctuation))
d_spleen: Dict[str, float] = dictionnaire_freq_mots(mots(ouvre_fichier("spleen"),   ponctuation))

candidats: List[Tuple[str, Dict[str, float]]] = [("beaute", d_beaute),("albatros", d_albatros),("spleen", d_spleen),]

assert auteur(candidats, "beaute") == "beaute"
assert auteur(candidats, "albatros") == "albatros"
assert auteur(candidats, "spleen") == "spleen"
