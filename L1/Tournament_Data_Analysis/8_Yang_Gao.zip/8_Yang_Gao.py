#Activité 18/11/2025

def ouvre_fichier(nom : str) -> List[str]:
    """ renvoie la liste des lignes du fichier texte ./ nom.csv """
    with open("./" + nom + ".csv", "r") as f:
        return f.readlines()


#1 Partie Guidée: Extraction d'information

exemple1: List[str] = ouvre_fichier('tournois')

#Q1)

def decompose_ligne(ligne: str, sep: str) -> List[str]:
    """Renvoie la chaîne de caractère ligne sans le caractère sep dedans."""
    res: List[str] = []
    i: str
    mot: str = ''
    for i in ligne:
        if i != '\n' and i != sep:
            mot = mot + i
        else:
            res.append(mot)
            mot = ''
    if mot != '':
        res.append(mot)
    return res

assert decompose_ligne(exemple1[0], ";") == ['"sport"', '"date"', '"participants"', '"vainqueur"']
assert decompose_ligne(exemple1[3], ";") == ['"karate"', '2021-09-26', '19', '"Carole"']
assert decompose_ligne(exemple1[3], ",") == ['"karate";2021-09-26;19;"Carole"']

#Q2)

def enleve_guillemets(s: str) -> str:
    """Renvoie la chaîne s sans guillemets l'encadrant s'il y en a."""
    if s[0] == '"' and s[-1] == '"':
        return s[1:-1]
    return s

assert enleve_guillemets('"sport"') == 'sport'
assert enleve_guillemets('sport') == 'sport'

#Q3)

def enleve_guillemets_ligne(li: List[str]) -> List[str]:
    """Renvoie la liste des éléments de li sans guillemets"""
    return [enleve_guillemets(i) for i in li]

assert enleve_guillemets_ligne(['"sport"', '"date"', '" participants "', '" vainqueur "']) == ['sport', 'date', ' participants ', ' vainqueur ']
assert enleve_guillemets_ligne(['"karate"', '2021 − 09 − 26', '19', '"Carole"']) == ['karate', '2021 − 09 − 26', '19', 'Carole']

#Q4)

def lignes_propres(lis:List[str], sep:str) -> List[List[str]]:
    """Renvoie une liste de liste de chaînes de caractère correspondant à la décomposition de chacune des lignes
de lis dans laquelle on a enlevé les guillemets qui entourent chaque élément, quand c’est le cas."""
    return [enleve_guillemets_ligne(i) for i in [decompose_ligne(li, sep) for li in lis]]

assert lignes_propres(exemple1, ";") == [['sport', 'date', 'participants', 'vainqueur'], ['boxe', '2021-09-18', '12', 'Alice'], ['boxe', '2021-09-25', '10', 'Alice'], ['karate', '2021-09-26', '19', 'Carole'], ['boxe', '2021-10-02', '8', 'Bob'], ['karate', '2021-10-03', '20', 'Carole'], ['tennis', '2021-10-04', '3', 'Alice'], ['boxe', '2021-10-09', '5', 'Alice'], ['karate', '2021-10-10', '20', 'Damien'], ['boxe', '2021-10-16', '6', 'Carole'], ['echecs', '2021-09-17', '120', 'Bob'], ['echecs', '2021-09-24', '120', 'Bob'], ['echecs', '2021-10-01', '120', 'Carole']]


#Q5

def cherche_indice(e:str, li:List[str]) -> Optional[int]:
    """Renvoie le premier indice de li auquel apparaît e si c’est le cas, et None sinon"""
    i:int
    for i in range(len(li)):
        if li[i]== e:
            return i
    return None

assert cherche_indice("sport", ['sport', 'date', 'participants', 'vainqueur']) == 0
assert cherche_indice("vainqueur", ['sport ', 'date', 'participants', 'vainqueur']) == 3
assert cherche_indice("deces", ['sport', 'date', 'participants', 'vainqueur']) == None

#Q6)
                      
def dictionnaire_compte(lis:List[List[str]], clef:str) -> Dict[str,int]:
    """Renvoie un dictionnaire dont les clefs sont les données de la colonne clef du fichier et ses valeurs sont leurs nombre d’occurences."""
    d:Dict[str,int] = dict()
    i:int = cherche_indice(clef,lis[0])
    e:List[str]
    for e in lis[1:]:
        if e[i] in d:
            d[e[i]] = d[e[i]] + 1
        else:
            d[e[i]] = 1
    return d
        
lignes_ex1: List[List[str]]= lignes_propres(exemple1 , ";")   
assert dictionnaire_compte(lignes_ex1, "vainqueur") == {'Alice': 4, 'Carole': 4, 'Bob': 3, 'Damien': 1}

assert dictionnaire_compte(lignes_ex1, "sport") == {'boxe': 5, 'karate': 3, 'tennis': 1, 'echecs': 3}

def dictionnaire_somme(lis: List[List[str]], clef: str, valeur: str) -> Dict[str,int]:
    """Précondition: les clefs et les valeurs de lis doivent exister (lis[i] != None).
    Renvoie un dictionnaire dont les clefs sont les données de la colonne clef du fichier et dont ses valeurs sont la somme des données de la colonne valeur des lignes ou k apparaît dans la colonne clef."""
    d: Dict[str,int] = dict()
    i: int = cherche_indice(clef,lis[0])
    j: int = cherche_indice(valeur, lis[0])
    ligne: List[str]
    for ligne in lis[1:]:
        k: str = ligne[i]
        v: int = int(ligne[j])
        if k in d:
            d[k] = d[k] + v
        else:
            d[k] = v

    return d

assert dictionnaire_somme(lignes_ex1, "sport", "participants") == {'boxe': 41, 'karate': 59, 'tennis': 3, 'echecs': 360}

#2 SUGGESTION: Courbes temporelles

def dates(lis: List[List[str]]) -> Set[str]:
    """Renvoie l'ensemble des dates uniques contenus dans lis"""
    date: Set[str] = set()
    ligne: List[str]
    for ligne in lis:
        date.add(ligne[2])
    return date

def date_j(d: str) -> int:
    """Renvoie la durée en jour de la date d en jours à partir de 2021-09-17"""
    return  (int(d[5:7]) - 9) * 31 + int(d[8:10]) - 17

assert date_j('2021-09-17') == 0
assert date_j('2021-09-24') == 7

def dates_jours(d: Set[str]) -> List[int]:
    """Renvoie la liste contenant les éléments de l'ensemble d"""
    res: List[int] = []
    date: str
    for date in d:
        res.append(date_j(date))
    return res

def dictionnaire_j_v(dico: Dict[str, int]) -> Dict[int, int]:
    """Convertit le dictionnaire dico associant date et valeur en dictionnaire associant durée depuis la première
date du dictionnaire et valeur."""
    res: Dict[int, int] = dict()
    for date_str, val in dico.items():
        jours: int = date_j(date_str)
        if jours in res:
            res[jours] = res[jours] + val
        else:
            res[jours] = val
    return res

def liste_j_v(d: Dict[int,int]) -> List[Tuple[int,int]]:
    """convertit le dictionnaire d en une liste d’associations (durée, valeur)"""
    res: List[Tuple[int,int]] = []
    i: int
    for i in d:
        res.append((i,d[i]))
    return res
        
def trie_liste_j_v(li: List[Tuple[int,int]]) -> List[Tuple[int,int]]:
    """Renvoie la liste d’associations selon la durée de façon croissante)"""
    res: List[Tuple[int,int]] = []
    i: int = 0
    while i < len(li):
        cle, val = li[i]
        gauche: List[Tuple[int,int]] = []
        droite: List[Tuple[int,int]] = []
        garder_gauche: bool = True
        j: int = 0
        while j < len(res):
            c_pos, v_pos = res[j]
            if garder_gauche and c_pos < cle:
                gauche.append((c_pos, v_pos))
            else:
                garder_gauche = False
                droite.append((c_pos, v_pos))
            j = j + 1
        res = gauche + [(cle, val)] + droite
        i = i + 1
    return res


def conversion(c: List[Tuple[int,int]]) -> List[Tuple[float,float]]:
    """Convertit les couples (durée, valeur) de lien points d'abscisses et ordonnées entre (-1,-1) et (1,1) approximativement pour que la courbe rendre dans le cadre."""
    res: List[Tuple[float,float]] = []
    for (j,v) in c:
        res.append((j*0.067 - 1, v*0.017 - 1))
    return res


def courbe() -> Image:
    """Trace la courbe de l’affluence de participants en fonction de la date"""
    res: Image = draw_line(0,0,0,0)
    lignes: List[List[str]] = lignes_propres(ouvre_fichier("tournois"), ";")
    d_date: Dict[str, int]= dictionnaire_somme(lignes, "date", "participants")
    d_days: Dict[int, int] = dictionnaire_j_v(d_date)
    pairs: List[Tuple[int,int]] = liste_j_v(d_days)
    pairs_triees: List[Tuple[int,int]] = trie_liste_j_v(pairs)
    pts: List[Tuple[float,float]] = conversion(pairs_triees)
    i: int = 0
    while i < len(pts) - 1:
        x1, y1 = pts[i]
        x2, y2 = pts[i + 1]
        res = overlay(res, draw_line(float(x1), float(y1), float(x2), float(y2)))
        i = i + 1
    return res

show_image(courbe())
