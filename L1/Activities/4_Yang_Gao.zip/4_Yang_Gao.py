#07/10/2025 Activité 4

#Préliminaires: Manipulation de fichier
def identite(s : str) -> str:
    """Renvoie la chaine s telle quelle"""
    return s

assert identite("LU1IN011") == "LU1IN011"
assert identite("") == ""

def identite_texte(nom : str) -> None:
    """ Precondition : <nom>.txt est un fichier existant
    recopie le contenu du fichier <nom>.txt dans <nom>-copie.txt """
    with open(nom + ".txt", "r") as source :
        with open(nom + "_copie.txt", "w") as destination:
            ligne : str
            for ligne in source.readlines():
                destination.write(identite(ligne))

#Partie Guidée: Chiffre de César

#Q1)

def est_majuscule(l: str) -> bool:
    """Précondition: len(l) == 1
    Regarde si l est une majuscule ou non"""
    if ord('A') <= ord(l) <= ord('Z'):
        return True
    return False
    
def est_minuscule(l: str) -> bool:
    """Précondition: len(l) == 1
    Regarde si l est une majuscule ou non"""
    if ord('a') <= ord(l) <= ord('z'):
        return True
    return False

assert est_majuscule("C") == True
assert not est_minuscule("C") == True
assert est_minuscule("c") == True
assert not est_majuscule("c") == True
assert not est_minuscule(" ") == True
assert not est_majuscule(" ") == True

#Q2)

def caractere_decale(c: str, n: int) -> str:
    """Précondition: len(c) == 1
    Renvoie le caractère c obtenu par décalage de n"""
    if est_minuscule(c):
        return chr(ord('a') + (ord(c) - ord('a') + n)%26)
    elif est_majuscule(c):
        return chr(ord('A') + (ord(c) - ord('A') + n)%26)
    else:
        return c

assert caractere_decale("a", 0) == "a"
assert caractere_decale("a", 3) == "d"
assert caractere_decale("A", 3) == "D"
assert caractere_decale("V", 8) == "D"
assert caractere_decale(" ", 3) == " "

#Q3)

def ligne_chiffre_cesar(c:str, n:int) -> str:
    """Renvoie la chaîne de caractère c par décalage de n"""
    ligne: str = ''
    i: str
    for i in c:
        ligne = ligne + caractere_decale(i, n)
    return ligne

assert ligne_chiffre_cesar("Bonjour LU1IN011", 3) == "Erqmrxu OX1LQ011"
assert ligne_chiffre_cesar("Bonjour LU1IN011", 0) == "Bonjour LU1IN011"

def ligne_dechiffre_cesar(c:str, n:int) -> str:
    """Renvoie la chaîne de caractère c par décalage de n"""
    ligne: str = ''
    i: str
    for i in c:
        ligne = ligne + caractere_decale(i, -n)
    return ligne

assert ligne_dechiffre_cesar("Erqmrxu OX1LQ011", 3) == "Bonjour LU1IN011"
assert ligne_dechiffre_cesar("Bonjour LU1IN011", 0) == "Bonjour LU1IN011"
beaute1: str = "Je suis belle, o mortels ! comme un reve de pierre,"
assert ligne_dechiffre_cesar(ligne_chiffre_cesar(beaute1, 12), 12) == beaute1


#Q4)

def chiffre_fichier_cesar(nom: str, n: int) -> None:
    """Précondition: le fichier nom.txt doit exister
    Chiffre le fichier nom par décalage de n"""
    with open(nom + ".txt", "r") as texte:
        with open(nom + "_cesar.txt", "w") as destination:
            ligne: str
            for ligne in texte.readlines():
                destination.write(ligne_chiffre_cesar(ligne, n))
                
def dechiffre_fichier_cesar(nom: str, n: int) -> None:
    """Précondition: le fichier nom.txt doit exister
        Dehiffre le fichier nom.txt par décalage de n"""
    with open(nom + ".txt", "r") as texte2:
        with open(nom + "_cesar_dechiffre.txt", "w") as destination:
            ligne: str
            for ligne in texte2.readlines():
                destination.write(ligne_dechiffre_cesar(ligne, n))


#3 SUGGESTION: Attaque

def dechiffre_fichier_cesar2(nom: str, n: int) -> None:
    """Précondition: le fichier nom.txt doit exister
        Dechiffre le fichier nom.txt par décalage de n"""
    with open(nom + ".txt", "r") as texte2:
        with open(nom + "_cesar_dechiffre.txt", "a") as destination: #"a" permet d'ajouter du texte dans le fichier sans écraser le précédent contrairement à "w"  
            ligne: str
            i:int = 0
            destination.write("\n" + "="*20 + "\n")
            destination.write("Décalage de : " + str(n) + "\n") #les \n permettent de retourner à la ligne
            for ligne in texte2.readlines():
                destination.write(ligne_dechiffre_cesar(ligne, n))
                i = i + 1
                if i > 10:
                    return None #permet de s'arreter à 10 lignes


def attaque_cesar(nom:str) -> None:
    """Précondition: le fichier nom.txt doit exister
        Déchiffre un passage du fichier nom.txt pour chaque décalage de 0 à 25"""
    with open(nom + "_cesar_dechiffre.txt", "w") as destination:
        destination.write("Lignes 0-10 :\n")
    d:int
    for d in range(26):
        dechiffre_fichier_cesar2(nom, d) #dechiffrement pour chaque decalage d


#4 SUGGESTION: Chiffre affine

def pgcd(n : int, m : int)->int:
     """Retourne le plus grand commun diviseur de n et m."""
     d: int = n
     r: int = m
     temp: int = 0
     while r != 0:
         temp = d % r
         d = r
         r = temp
     return d

def rendre_premier_avec_26(n: int) -> int:
    """Retourne un entier >= n tel que pgcd(entier, 26) == 1."""
    x:int = n
    while pgcd(x, 26) != 1:
        x = x + 1
    return x

def inverse(a:int)->int:
    """Précondition: a >= 0
    Donne un inverse de a"""
    x:int = 0
    while (a*x)%26 != 1:
        x = x + 1
    return x

def ligne_chiffre_affine(c: str, a: int, b: int) -> str:
    """Chiffre un texte par chiffrement affine"""
    resultat:str = ""
    i:str
    for i in c:
        if est_majuscule(i):
            A:int = a
            if pgcd(a, 26) != 1:
                A = rendre_premier_avec_26(a)
            x:int = ord(i) - ord('A')
            y:int = (A * x + b) % 26
            resultat = resultat + chr(ord('A') + y)
        elif est_minuscule(i):
            A:int = a
            if pgcd(a, 26) != 1:
                A = rendre_premier_avec_26(a)
            x:int = ord(i) - ord('a')
            y:int = (A * x + b) % 26
            resultat = resultat + chr(ord('a') + y)
        else:
            resultat = resultat + i
    return resultat


def ligne_dechiffre_affine(c: str, a: int, b: int) -> str:
    """Déchiffre un texte chiffré affinement"""
    resultat: str = ""
    i:str
    for i in c:
        if est_majuscule(i):
            A: int = a
            if pgcd(a, 26) != 1:
                A:int = rendre_premier_avec_26(a)
            a_inv: int = inverse(A)
            y:int = ord(i) - ord('A')
            x:int = (a_inv * (y - b)) % 26
            resultat = resultat + chr(ord('A') + x)
        elif est_minuscule(i):
            A: int = a
            if pgcd(a, 26) != 1:
                A:int = rendre_premier_avec_26(a)
            a_inv: int = inverse(A)
            y:int = ord(i) - ord('a')
            x:int = (a_inv * (y - b)) % 26
            resultat = resultat + chr(ord('a') + x)
        else:
            resultat = resultat + i
    return resultat


assert ligne_chiffre_affine("Bonjour LU1IN011 !", 3, 7) == "Kxuixpg OP1FU011 !"
assert ligne_chiffre_affine("Bonjour LU1IN011 !", 2, 7) == "Kxuixpg OP1FU011 !"
assert ligne_chiffre_affine("Bonjour LU1IN011 !", 14, 47) == "Kxiaxjq EJ1LI011 !"
assert ligne_dechiffre_affine("Kxuixpg OP1FU011 !", 3, 7) == "Bonjour LU1IN011 !"
assert ligne_dechiffre_affine("Kxuixpg OP1FU011 !", 2, 7) == "Bonjour LU1IN011 !"
assert ligne_dechiffre_affine("Kxiaxjq EJ1LI011 !", 14, 47) == "Bonjour LU1IN011 !"
beaute1_c : str = ligne_chiffre_affine(beaute1, 28, 2016)
assert ligne_dechiffre_affine(beaute1_c , 28, 2016) == beaute1
